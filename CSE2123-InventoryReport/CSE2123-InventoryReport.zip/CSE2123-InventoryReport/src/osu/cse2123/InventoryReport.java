package osu.cse2123;
/**
 * A program that generates an inventory report
 * 
 * @name YOUR NAME HERE
 * @version DATE HERE
 * 
 */

public class InventoryReport {

	public static void main(String[] args) {
		// TODO Your Code Here

	}

}
